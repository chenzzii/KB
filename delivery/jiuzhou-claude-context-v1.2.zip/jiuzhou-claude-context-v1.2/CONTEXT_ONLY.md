此為輕量文字上下文包，未包含 PNG、美術音訊證據、原始 ZIP 或可玩的 web-build。請另取完整交接包，或 clone GitHub 的 delivery/jiuzhou-v1 分支後執行遊戲。
