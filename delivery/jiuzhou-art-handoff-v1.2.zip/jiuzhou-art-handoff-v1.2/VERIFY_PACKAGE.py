import hashlib,json,sys
from pathlib import Path
root=Path(__file__).resolve().parent
manifest=json.loads((root/'SHA256_MANIFEST.json').read_text(encoding='utf-8'))
errors=[]
for name,expected in manifest['files'].items():
 p=(root/name).resolve()
 if not p.is_relative_to(root) or not p.is_file() or hashlib.sha256(p.read_bytes()).hexdigest()!=expected['sha256']:errors.append(name)
if errors:print('FAILED',errors);sys.exit(1)
print('PASS:',len(manifest['files']),'files match SHA-256')
