# 九州兵譜：烽火歸途 v1.2 — 靜態成品

此 ZIP 已含建置完成的遊戲、美術圖集、25 種兵種分層動作及兩首新作配樂，不需要 npm install。請使用 HTTP 靜態服務開啟。

若已裝 Python 3，進入解壓後的 jiuzhou-v1.2 資料夾執行：

```sh
python -m http.server 8080
```

Linux 可將 python 改為 python3，再以瀏覽器開啟 http://localhost:8080/ 。也可將整個資料夾部署至靜態網頁服務，不需要後端或帳號。

線上遊玩：https://chenzzii.github.io/KB/?v=1.2

配樂預設關閉，按「配樂 開」啟用；地圖播放〈青嵐遠行〉，戰鬥播放〈烽鼓破陣〉，自動換曲。音量可調整，音效分開開關。動作預設開啟，可手動關閉，並遵循系統的減少動態效果設定。

抵達柳灣鄉營等據點後，按「招募部曲」選兵種與人數。地圖與核心規則未變，舊存檔可繼續匯入。圖片約 16.8 MB，首次開啟需載入。

詳見 MOTION_MUSIC_V1_2.md、RUNNING.md 與原設定差異盤點 FINAL_COMPARISON.md。RUNNING.md 的 npm 指令適用完整原始碼，這份成品 ZIP 不含 package.json。
