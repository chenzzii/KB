# 九州兵譜：烽火歸途 — 靜態成品

此 ZIP 已含建置完成的遊戲、全部 86 SVG 與音樂程式，不需要 npm install。
請透過 HTTP 靜態服務開啟，不要直接雙擊 index.html。

若已裝 Python 3，進入此資料夾後執行：

```sh
python -m http.server 8080
```

Linux 可將 python 改為 python3，再於本機瀏覽器開啟 localhost 的 8080 埠。
也可以將整個資料夾交給任何靜態網頁服務，不需要後端或帳號。

RUNNING.md 內 npm 指令適用完整原始碼專案，這份成品 ZIP 不含 package.json。
遊戲預設開啟完整冒險；頂端頁籤另有演武、兵譜、研究說明與完整美術圖鑑。
完整差異盤點見 FINAL_COMPARISON.md。沒有部署至任何公開服務。
