#!/usr/bin/env python3
import hashlib, json, sys, zipfile
from pathlib import Path
root=Path(__file__).resolve().parent
manifest=json.loads((root/'SHA256_MANIFEST.json').read_text(encoding='utf-8'))
errors=[]
for name, record in manifest['files'].items():
 path=(root/name).resolve()
 if not path.is_relative_to(root) or not path.is_file():
  errors.append('Missing or unsafe path: '+name);continue
 data=path.read_bytes()
 if len(data)!=record['bytes'] or hashlib.sha256(data).hexdigest()!=record['sha256']:
  errors.append('Hash mismatch: '+name)
original=root/'original_handoff/development_pack_v1.zip'
count=0
if original.exists():
 with zipfile.ZipFile(original) as archive:
  for item in archive.infolist():
   if item.is_dir():continue
   relative=Path(*Path(item.filename).parts[1:])
   if not relative.parts or '..' in relative.parts:
    errors.append('Unsafe original path');continue
   target=root/'project'/relative
   if not target.is_file() or target.read_bytes()!=archive.read(item):
    errors.append('Original handoff changed: '+str(relative))
   count+=1
if errors:
 print('FAILED\n'+'\n'.join(errors));sys.exit(1)
print(f"PASS: {len(manifest['files'])} files verified; {count} original handoff files compared.")
