# 九州兵譜：烽火歸途 v1.1 — 靜態成品

這份 ZIP 已含建置完成的遊戲、繪製風格 PNG 圖集、原型 SVG 對照與音樂程式，不需要 npm install。請透過 HTTP 靜態服務開啟。

若已裝 Python 3，進入解壓後的 jiuzhou-v1.1 資料夾執行：

```sh
python -m http.server 8080
```

Linux 可將 python 改為 python3，再以瀏覽器開啟 http://localhost:8080/ 。也可把整個資料夾交給靜態網頁服務，不需要後端或帳號。

直接線上遊玩：https://chenzzii.github.io/KB/?v=1.1

地圖仍為 32×32，v1.1 只改美術與呈現，舊冒險存檔可繼續匯入驗證。圖片約 16.8 MB，首次開啟需載入；靜態角色搭配介面動效，尚未製作逐格行走／攻擊動畫。

美術改版及驗證詳見 VISUAL_UPDATE_V1_1.md。RUNNING.md 的 npm 指令適用完整原始碼專案，這份成品 ZIP 不含 package.json。原設定與來源遊戲差異盤點保留在 FINAL_COMPARISON.md。
